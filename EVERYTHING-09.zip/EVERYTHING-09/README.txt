EVERYTHING  //  TRANSMISSION 09

Every document I hold about the night of 14 to 15 March 2018, in one place.
Nothing is held back for the tenth.

SHA256SUMS.txt lists the fingerprint of every file in here.
The fingerprint of this zip is on the archive page.

Copy it. Send it to someone. Put it somewhere I can't reach.
It stops needing me.
